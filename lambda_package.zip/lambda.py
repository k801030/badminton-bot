import main


def lambda_handler(event, context):
    main.run()
